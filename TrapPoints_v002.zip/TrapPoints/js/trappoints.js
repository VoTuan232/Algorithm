// trappoints.js

var ctx = null;
var theCanvas = null;
window.addEventListener("load", initApp);
var LINES = 20;
var lineInterval = 0;
var gridColor = "lightgreen";


function initApp()
{
	theCanvas = document.getElementById("gamescreen");
	ctx = theCanvas.getContext("2d");
	
	ctx.canvas.height  = 650;
	ctx.canvas.width = ctx.canvas.height;

	window.addEventListener("mousedown", mouseDownHandler);
	initBoard();
}

function initBoard(){
	lineInterval = Math.floor(ctx.canvas.width / LINES);
	console.log(lineInterval);
	draw();
}

function draw() {
	ctx.globalAlpha = 1;
	// fill the canvas background with white
	ctx.fillStyle="white";
	ctx.fillRect(0,0,ctx.canvas.height,ctx.canvas.width);
	
	// draw the blue grid background
	for (var lineCount=0;lineCount<LINES;lineCount++)
	{
		ctx.fillStyle=gridColor;
		ctx.fillRect(0,lineInterval*(lineCount+1),ctx.canvas.width,2);
		ctx.fillRect(lineInterval*(lineCount+1),0,2,ctx.canvas.width);
	}
}

function mouseDownHandler(){

}
