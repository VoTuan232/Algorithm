// trappoints.js

var ctx = null;
var theCanvas = null;
window.addEventListener("load", initApp);
var LINES = 20;
var lineInterval = 0;
var gridColor = "lightgreen";
var allPoints = [];
var RADIUS = 10;


function initApp()
{
	theCanvas = document.getElementById("gamescreen");
	ctx = theCanvas.getContext("2d");
	
	ctx.canvas.height  = 650;
	ctx.canvas.width = ctx.canvas.height;

	window.addEventListener("mousedown", mouseDownHandler);
	initBoard();
}

function initBoard(){
	lineInterval = Math.floor(ctx.canvas.width / LINES);
	console.log(lineInterval);
	draw();
}

function draw() {
	ctx.globalAlpha = 1;
	// fill the canvas background with white
	ctx.fillStyle="white";
	ctx.fillRect(0,0,ctx.canvas.height,ctx.canvas.width);
	
	// draw the blue grid background
	for (var lineCount=0;lineCount<LINES;lineCount++)
	{
		ctx.fillStyle=gridColor;
		ctx.fillRect(0,lineInterval*(lineCount+1),ctx.canvas.width,2);
		ctx.fillRect(lineInterval*(lineCount+1),0,2,ctx.canvas.width);
	}
}

function getMousePos(evt) {
	
	var rect = theCanvas.getBoundingClientRect();
	var currentPoint = {};
	currentPoint.x = evt.clientX - rect.left;
	currentPoint.y = evt.clientY - rect.top;
	return currentPoint;
}

function clearPoints(){
	// clear all the points from the array
	allPoints = [];
	// redraw the background grid (erasing the points);
	draw();
}

function drawLine(p, p2){
	ctx.beginPath();
	ctx.moveTo(p.x,p.y);
	ctx.lineTo(p2.x, p2.y);
	console.log ("p.x : " + p.x + " p.y : " + p.y + " p2.x : " + p2.x + " p2.y : " +  p2.y);
	ctx.stroke();
}

function connectPoints(){
	console.log("connecting points...");
	
	if (allPoints === null || allPoints.length < 3){
		console.log("there are not enough points to do calculation.");
		return;
	}
	for (var x = 0;x < allPoints.length-1;x++){
		drawLine(allPoints[x],allPoints[x+1]);
		console.log("x+1 : " + x+1);
	}
	// draws back to the first point.
	drawLine(allPoints[allPoints.length-1], allPoints[0]);
}

function drawPoint(currentPoint){
	ctx.beginPath();
	ctx.arc(currentPoint.x, currentPoint.y,RADIUS,0,2*Math.PI);
	allPoints.push(currentPoint);
	ctx.stroke();
}

function mouseDownHandler(event){
	
	if (event.button == 0){
		var currentPoint = getMousePos(event);
		if ((currentPoint.x > 650) || (currentPoint.y > 650))
		{
			return;
		}
		drawPoint(currentPoint);
		console.log(currentPoint);
	}
}
