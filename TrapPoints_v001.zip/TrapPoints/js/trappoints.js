// trappoints.js

var ctx = null;
var theCanvas = null;
window.addEventListener("load", initApp);

function initApp()
{
	theCanvas = document.getElementById("gamescreen");
	ctx = theCanvas.getContext("2d");
	
	ctx.canvas.height  = 650;
	ctx.canvas.width = ctx.canvas.height;

	window.addEventListener("mousedown", mouseDownHandler);
}

function mouseDownHandler(){

}
